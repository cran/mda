"gplot" <-
function(x, ...)
UseMethod("gplot")
