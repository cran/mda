labels.Gam<-function(object,...){
      attr(object$terms, "term.labels")
    }
