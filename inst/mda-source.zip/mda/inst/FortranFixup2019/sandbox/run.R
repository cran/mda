source("code.R")
stripFortranLabels("backfit")
stripFortranLabels("backlo")
stripFortranLabels("linear")
stripFortranLabels("lo")
stripFortranLabels("loessf")
stripFortranLabels("qsbart")
stripFortranLabels("splsm")
stripFortranLabels("sslvrg")
stripFortranLabels("bvalue")
stripFortranLabels("bsplvd")


