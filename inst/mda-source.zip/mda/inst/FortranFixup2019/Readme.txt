Original fortran contains the files as of June 1 2019,
which started giving crap warnings in R 3.6

Edited Naras contains edited versions by Naras to remove tabs for some
of the files

These get copied into sandbox, and then the run.R script is run.
The changed versions are put in Fixed directory of sandbox

These get copied into the gam package src directory, overwriting whats there.
